var searchData=
[
  ['add_5fexternal_5forder_54',['add_external_order',['../elevator__control_8h.html#ae98d5fa271dc23a321a7f0b1ebcf2b3e',1,'elevator_control.c']]],
  ['add_5finternal_5forder_55',['add_internal_order',['../elevator__control_8h.html#ac2abc864fdab858c9c040899ebe91cb3',1,'elevator_control.c']]],
  ['add_5forder_56',['add_order',['../elevator__control_8h.html#a18f5d1f04508630aa32ac8a91015f12a',1,'elevator_control.c']]]
];
