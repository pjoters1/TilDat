var searchData=
[
  ['repeat_5fcheck_81',['repeat_check',['../elevator__control_8h.html#aad3bd9df1a3342ad1a0c6800fb830374',1,'elevator_control.c']]],
  ['reset_5felevator_82',['reset_elevator',['../elevator__control_8h.html#a3360d2b8ff80b7dbf8bcdc321495e174',1,'elevator_control.c']]],
  ['reset_5ftimer_83',['reset_timer',['../timer_8h.html#aa3ef1744ca7e52c293c49ccef26798e8',1,'timer.c']]]
];
