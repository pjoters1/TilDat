var searchData=
[
  ['set_5fstop_42',['set_stop',['../elevator__control_8h.html#a792d61e1c7d59b0544518066e701ee58',1,'elevator_control.c']]],
  ['set_5ftimer_43',['set_timer',['../timer_8h.html#af2a9f1fee798207986fcdd6a51543e42',1,'timer.c']]],
  ['stop_5felevator_44',['stop_elevator',['../elevator__control_8h.html#abde120ae193ca60a52b7ab4c1f28761a',1,'elevator_control.c']]],
  ['stop_5fsignal_5factivated_45',['stop_signal_activated',['../buttons_8h.html#aeea2bf5af86030da4a678444920361d2',1,'buttons.c']]],
  ['stopped_46',['stopped',['../elevator__control_8h.html#a8074ae2bff6f2b3253f1b2685c239b79',1,'elevator_control.c']]]
];
