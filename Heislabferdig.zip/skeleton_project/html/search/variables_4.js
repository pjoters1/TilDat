var searchData=
[
  ['stopped_93',['stopped',['../elevator__control_8h.html#a8074ae2bff6f2b3253f1b2685c239b79',1,'elevator_control.c']]]
];
