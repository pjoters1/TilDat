var searchData=
[
  ['queue_5falgo_79',['queue_algo',['../queue_8h.html#a352ce31a434c615b988bda563463d351',1,'queue.c']]]
];
