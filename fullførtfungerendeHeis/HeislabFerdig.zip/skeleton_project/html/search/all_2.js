var searchData=
[
  ['check_5fextremities_4',['check_extremities',['../queue_8h.html#ac1e720f2962df4985a01c2701220f8c4',1,'queue.h']]],
  ['clear_5fall_5forder_5flights_5',['clear_all_order_lights',['../elevator__control_8h.html#afd77151474c3e94d7c52fd75413ae3ca',1,'elevator_control.c']]],
  ['clear_5fall_5forders_6',['clear_all_orders',['../elevator__control_8h.html#a6206e5203639ca23d84820e2ffb108a3',1,'elevator_control.c']]]
];
